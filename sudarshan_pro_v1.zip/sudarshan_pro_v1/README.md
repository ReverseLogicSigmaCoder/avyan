# SUDARSHAN Pro - Automated Security Audit & PDF Report Generator

Lightweight Python tool for automated passive security scanning and standard PDF compliance report generation.

## 🚀 How to Install & Run

1. **Install Dependencies:**
   ```bash
   pip install requests reportlab urllib3
