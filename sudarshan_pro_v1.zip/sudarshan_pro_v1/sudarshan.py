import os
import requests
import urllib3
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def run_scanner(domain):
    target_url = domain.strip()
    if not target_url.startswith("http"):
        target_url = "https://" + target_url

    print(f"[*] Scanning Target: {target_url} ...")
    vulnerabilities = []

    try:
        response = requests.get(target_url, timeout=10, verify=False)
        headers = response.headers

        # Check Missing Headers
        security_headers = {
            "Strict-Transport-Security": "Enforces HTTPS connections.",
            "X-Frame-Options": "Protects against Clickjacking attacks.",
            "X-Content-Type-Options": "Prevents MIME-sniffing vulnerabilities.",
            "Content-Security-Policy": "Mitigates XSS and data injection attacks."
        }

        for header, desc in security_headers.items():
            if header not in headers:
                vulnerabilities.append({
                    "title": f"Missing Header: {header}",
                    "severity": "Medium" if header in ["Strict-Transport-Security", "Content-Security-Policy"] else "Low",
                    "description": desc,
                    "remediation": f"Configure '{header}' in web server response headers."
                })

        if "Server" in headers:
            vulnerabilities.append({
                "title": "Server Information Disclosure",
                "severity": "Low",
                "description": f"Server exposes backend banner: {headers['Server']}",
                "remediation": "Disable Server tokens / banner in web server config."
            })

    except Exception as e:
        print(f"[-] Connection Error: {e}")

    return target_url, vulnerabilities

def generate_pdf(target_url, vulns, output_filename="SUDARSHAN_Audit_Report.pdf"):
    doc = SimpleDocTemplate(output_filename, pagesize=letter)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor("#1A365D"), spaceAfter=12)
    heading_style = ParagraphStyle('HeadingStyle', parent=styles['Heading3'], fontSize=12, textColor=colors.HexColor("#2B6CB0"), spaceAfter=6)
    normal_style = ParagraphStyle('NormalStyle', parent=styles['Normal'], fontSize=10, leading=14, spaceAfter=8)

    story = [
        Paragraph("PROJECT AVYAN - SUDARSHAN SECURITY REPORT", title_style),
        Paragraph(f"<b>Target Endpoint:</b> {target_url}", normal_style),
        Paragraph(f"<b>Audit Scope:</b> Passive Header & Misconfiguration Audit", normal_style),
        Spacer(1, 15)
    ]

    if not vulns:
        story.append(Paragraph("<b>Result:</b> No basic security misconfigurations detected.", normal_style))
    else:
        for idx, item in enumerate(vulns, 1):
            story.append(Paragraph(f"{idx}. {item['title']} [{item['severity']} Risk]", heading_style))
            story.append(Paragraph(f"<b>Impact:</b> {item['description']}", normal_style))
            story.append(Paragraph(f"<b>Remediation:</b> {item['remediation']}", normal_style))
            story.append(Spacer(1, 10))

    doc.build(story)
    print(f"[+] Report generated successfully: {output_filename}")

if __name__ == "__main__":
    target = input("Enter Target Domain (e.g., example.com): ")
    if target:
        url, findings = run_scanner(target)
        generate_pdf(url, findings)
